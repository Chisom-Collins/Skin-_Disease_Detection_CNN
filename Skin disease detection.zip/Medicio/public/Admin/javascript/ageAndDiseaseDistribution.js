// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Function to calculate age from date of birth
function calculateAge(dob) {
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

// Function to get patient data and group by age and disease
async function getAgeGroupDiseaseDistribution() {
    const diseaseAgeGroupDistribution = {
        "0-10": {},
        "11-20": {},
        "21-30": {},
        "31-40": {},
        "41-50": {},
        "51-60": {},
        "61+": {}
    };

    const colors = {}; // Object to store unique colors for each disease

    try {
        // Check if the user is authenticated
        onAuthStateChanged(auth, async (user) => {
            if (user) {
                const querySnapshot = await getDocs(collection(db, "Patients"));
                querySnapshot.forEach((doc) => {
                    const data = doc.data();
                    const age = calculateAge(data.dob); // Calculate age
                    const disease = data.diagnosis; // Use the diagnosis field directly

                    // Determine the age group
                    let ageGroup;
                    if (age <= 10) ageGroup = "0-10";
                    else if (age <= 20) ageGroup = "11-20";
                    else if (age <= 30) ageGroup = "21-30";
                    else if (age <= 40) ageGroup = "31-40";
                    else if (age <= 50) ageGroup = "41-50";
                    else if (age <= 60) ageGroup = "51-60";
                    else ageGroup = "61+";

                    // Initialize disease count for each age group if not already done
                    if (!diseaseAgeGroupDistribution[ageGroup][disease]) {
                        diseaseAgeGroupDistribution[ageGroup][disease] = 0;
                    }
                    diseaseAgeGroupDistribution[ageGroup][disease]++;

                    // Assign a random color if this disease doesn't have one yet
                    if (!colors[disease]) {
                        colors[disease] = `rgba(${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, ${Math.floor(Math.random() * 256)}, 0.8)`;
                    }
                });

                console.log("Disease Age Group Distribution:", diseaseAgeGroupDistribution); // Debug log
                renderAgeGroupDiseaseChart(diseaseAgeGroupDistribution, colors);
            } else {
                console.log("User is not authenticated.");
                alert("You must be logged in to view the data.");
            }
        });
    } catch (error) {
        console.error("Error retrieving data:", error);
    }
}

// Function to render the chart with dynamic colors and y-axis from 1 to 5
function renderAgeGroupDiseaseChart(diseaseAgeGroupDistribution, colors) {
    const ctx = document.getElementById("ageGroupDiseaseChart").getContext("2d");

    // Prepare datasets dynamically from the diseaseAgeGroupDistribution
    const datasets = [];

    // Build a dataset for each disease
    Object.keys(colors).forEach(disease => {
        const data = Object.keys(diseaseAgeGroupDistribution).map(ageGroup => diseaseAgeGroupDistribution[ageGroup][disease] || 0);
        datasets.push({
            label: disease,
            data: data,
            backgroundColor: colors[disease],
            borderColor: colors[disease],
            borderWidth: 1
        });
    });

    console.log("Datasets for Chart:", datasets); // Debug log

    // Render the chart
    new Chart(ctx, {
        type: "bar",
        data: {
            labels: Object.keys(diseaseAgeGroupDistribution),
            datasets: datasets
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: "Age Groups"
                    }
                },
                y: {
                    title: {
                        display: true,
                        text: "Number of Patients"
                    },
                    beginAtZero: true,
                    min: 1,
                    max: 5,
                    ticks: {
                        stepSize: 1, // Ensures y-axis displays whole numbers
                        callback: function(value) { return Number.isInteger(value) ? value : null; }
                    }
                }
            }
        }
    });
}

// Fetch the data and render the chart when the page loads
getAgeGroupDiseaseDistribution();
