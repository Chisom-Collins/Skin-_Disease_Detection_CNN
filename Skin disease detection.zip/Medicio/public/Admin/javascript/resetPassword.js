import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getAuth, sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Your Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();

document.addEventListener('DOMContentLoaded', function () {
    const resetForm = document.getElementById('resetForm'); // Fix this query selector
    const emailInput = document.getElementById('email');

    resetForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent default form submission

        const email = emailInput.value.trim();

        // Simple email validation
        if (!validateEmail(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        // Firebase Authentication: Send password reset email
        sendPasswordResetEmail(auth, email)
            .then(() => {
                // If successful
                alert('A password reset link has been sent to ' + email);
            })
            .catch((error) => {
                // Handle error
                const errorMessage = error.message;
                alert('Error: ' + errorMessage);
            });
    });

    // Function to validate email format
    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
});
