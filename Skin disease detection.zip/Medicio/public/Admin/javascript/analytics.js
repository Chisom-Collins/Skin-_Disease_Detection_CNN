// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase and Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Function to calculate age from date of birth
function calculateAge(dob) {
    const birthDate = new Date(dob);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDifference = today.getMonth() - birthDate.getMonth();
    if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

// Function to get patient age distribution and group by age ranges
async function getAgeDistribution() {
    const ageGroups = { "0-10": 0, 
        "11-20": 0, 
        "21-30": 0, 
        "31-40": 0, 
        "41-50": 0,
        "51-60": 0, 
        "61+": 0 };

    try {
        // Check if the user is authenticated
        onAuthStateChanged(auth, async (user) => {
            if (user) {
                // Retrieve patient data from Firestore
                const querySnapshot = await getDocs(collection(db, "Patients"));
                querySnapshot.forEach((doc) => {
                    const data = doc.data();
                    console.log("Patient Data:", data); // Debug: Log patient data

                    const age = calculateAge(data.dob); // Assuming 'dob' is stored in YYYY-MM-DD format
                    console.log("Calculated Age:", age); // Debug: Log the calculated age

                    // Categorize ages into groups
                    if (age <= 10) ageGroups["0-10"]++;
                    else if (age <= 20) ageGroups["11-20"]++;
                    else if (age <= 30) ageGroups["21-30"]++;
                    else if (age <= 40) ageGroups["31-40"]++;
                    else if (age <= 50) ageGroups["41-50"]++;
                    else if (age <= 60) ageGroups["51-60"]++;
                    else ageGroups["61+"]++;

                    // Debug: Log which age group this patient falls into
                    console.log(`Patient ${data.fullName} (Age: ${age}) is categorized under: ${getAgeGroup(age)}`);
                });

                console.log("Age Groups:", ageGroups); // Debug: Log final age distribution
                renderAgeDistributionChart(ageGroups);
            } else {
                console.log("User is not authenticated.");
                alert("You must be logged in to view the data.");
            }
        });
    } catch (error) {
        console.error("Error retrieving age distribution:", error);
    }
}

// Helper function to determine age group for debugging purposes
function getAgeGroup(age) {
    if (age <= 10) return "0-10";
    if (age <= 20) return "11-20";
    if (age <= 30) return "21-30";
    if (age <= 40) return "31-40";
    if (age <= 50) return "41-50";
    if (age <= 60) return "51-60";
    return "61+";
}

// Function to render the chart with improved styles
function renderAgeDistributionChart(ageGroups) {
    const ctx = document.getElementById("ageDistributionChart").getContext("2d");
    new Chart(ctx, {
        type: "line", // line chart
        data: {
            labels: Object.keys(ageGroups),
            datasets: [{
                label: "Number of Patients",
                data: Object.values(ageGroups),
                borderColor: "#FF6384", // Line color
                backgroundColor: "rgba(255, 99, 132, 0.4)", // Line fill color
                borderWidth: 4,
                fill: true, // Fill the area under the line
                tension: 0.6 // Smooth the line curve
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: "#333",
                        font: {
                            size: 14
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: "Age Groups"
                    }
                },
                y:{
                 title: {
                    display: true,
                    text: "Number of Patients"
                },
                beginAtZero: true,
                min: 0,
                max: 6,
                ticks: {
                    stepSize: 1, // Ensures y-axis displays whole numbers
                    callback: function(value)
                     { return Number.isInteger(value) ? value : null; }
                }
                }
            }
        }
    });
}

// Call the function to get the age distribution when the page loads
getAgeDistribution();
