import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase and Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth();

// Function to calculate the frequency of each diagnosis over time
async function getDiagnosisFrequency() {
    const diagnosisFrequency = {};

    try {
        const querySnapshot = await getDocs(collection(db, "Diagnoses"));
        querySnapshot.forEach((doc) => {
            const data = doc.data();
            const diagnosisType = data.diagnosisType; // Assuming 'diagnosisType' field is in the data
            diagnosisFrequency[diagnosisType] = (diagnosisFrequency[diagnosisType] || 0) + 1;
        });

        console.log("Diagnosis Frequency:", diagnosisFrequency); // Debug: Log the frequency of each diagnosis
        renderDiagnosisFrequencyChart(diagnosisFrequency);
    } catch (error) {
        console.error("Error retrieving diagnosis frequency:", error);
    }
}

// Function to render the diagnosis frequency chart
function renderDiagnosisFrequencyChart(diagnosisFrequency) {
    const ctx = document.getElementById("diagnosisFrequencyChart").getContext("2d");

    new Chart(ctx, {
        type: "pie", // Pie chart to show the distribution of diagnosis types
        data: {
            labels: Object.keys(diagnosisFrequency),
            datasets: [{
                data: Object.values(diagnosisFrequency),
                backgroundColor: [
                    "#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF", "#FF9F40", "#FF6384"
                ]
            }]
        },
        options: {
            responsive: true
        }
    });
}

// Call the functions to fetch data and render the charts
getDiagnosisFrequency();
