// Firebase configuration and initialization
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, doc, updateDoc, getDoc } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';

const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const firestore = getFirestore(app);
const storage = getStorage(app);

// Hardcoded patient ID for testing (this should be dynamic in a real implementation)
const patientId = '1234566';

// Function to handle image upload
async function uploadImage() {
    const fileInput = document.getElementById('imageUpload'); // Get the image file input element
    const file = fileInput.files[0]; // Get the first file

    if (!file) {
        alert('Please select an image to upload.');
        return;
    }

    try {
        // 1. Define the storage reference path for the image
        const storageRef = ref(storage, `patients/${patientId}/images/${file.name}`);

        // 2. Upload the image to Firebase Storage
        const uploadResult = await uploadBytes(storageRef, file);

        // 3. Get the download URL of the uploaded image
        const downloadURL = await getDownloadURL(uploadResult.ref);

        // 4. Save the image URL to the Firestore database in the patient's document
        const patientRef = doc(firestore, 'Patients', patientId); // Use patient ID as the document ID
        await updateDoc(patientRef, { imageUrl: downloadURL });

        // Confirmation message
        alert('Image uploaded and URL saved to database successfully.');

        // Optional: Redirect to another page or perform additional actions after upload
        window.location.href = 'imageUploaded.html';

    } catch (error) {
        console.error('Error uploading image:', error);
        alert('Failed to upload image and save to database. Please try again.');
    }
}

// Call this function on form submission or button click
document.getElementById('uploadButton').addEventListener('click', uploadImage);
