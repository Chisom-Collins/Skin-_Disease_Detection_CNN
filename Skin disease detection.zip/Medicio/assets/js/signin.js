import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.addEventListener("DOMContentLoaded", function () {
    const signInForm = document.getElementById("signInForm");

    if (!signInForm) {
        console.error("Sign-in form not found in the DOM.");
        return;
    }

    signInForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        if (email === "" || password === "") {
            displayError("Please fill in both email and password.");
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            displayError("Please enter a valid email address.");
            return;
        }

        signInForm.querySelector("button").disabled = true;

        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                const user = userCredential.user;
                console.log("User signed in:", user.uid);

                const userDocRef = doc(db, "Dermatologists", user.uid);
                console.log("Fetching document at:", userDocRef.path);

                getDoc(userDocRef)
                    .then((docSnapshot) => {
                        if (docSnapshot.exists()) {
                            alert("Sign in successful!");
                            window.location.href = "actualpage.html";
                        } else {
                            displayError("User not found in dermatologists database.");
                        }
                    })
                    .catch((error) => {
                        console.error("Error fetching user data:", error.message);
                        displayError("Error fetching user data: " + error.message);
                    })
                    .finally(() => {
                        signInForm.querySelector("button").disabled = false;
                    });
            })
            .catch((error) => {
                console.error("Error signing in:", error.message);
                displayError(`Error: ${error.message}`);
                signInForm.querySelector("button").disabled = false;
            });
    });

    // Function to display error messages in the dialog box
    function displayError(message) {
        const errorDialog = document.getElementById("errorDialog");
        const errorDialogMessage = document.getElementById("errorDialogMessage");
        const closeDialog = document.getElementById("closeDialog");

        if (errorDialog && errorDialogMessage) {
            errorDialogMessage.textContent = message;
            errorDialog.style.display = "flex"; // Show the dialog

            // Close the dialog when the close button is clicked
            closeDialog.onclick = () => {
                errorDialog.style.display = "none";
            };
            // Close the dialog when clicking outside the dialog content
            window.onclick = (event) => {
                if (event.target === errorDialog) {
                    errorDialog.style.display = "none";
                }
            };
        } else {
            alert(message); 
        }
    }
});
