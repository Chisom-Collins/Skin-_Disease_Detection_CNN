import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, query, where, getDocs, updateDoc } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js';
import { setPersistence, browserSessionPersistence } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js';

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase services
const app = initializeApp(firebaseConfig);
const firestore = getFirestore(app);
const storage = getStorage(app);
const auth = getAuth(app);

setPersistence(auth, browserSessionPersistence).then(() => {
    console.log("Auth persistence set to session");
}).catch((error) => {
    console.error("Error setting auth persistence:", error);
});

// Function to get the patient identity number from the URL parameters
function getPatientIdentityNumber() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('patientId'); // Ensure the parameter matches the one used during redirection
}

// Function to load patient details from Firestore
async function loadPatientDetails() {
    const patientIdentityNumber = getPatientIdentityNumber(); // Get patient ID from URL
    if (!patientIdentityNumber) {
        alert('Patient ID not found. Please check the URL.');
        return;
    }

    const patientsRef = collection(firestore, 'Patients');
    const q = query(patientsRef, where('identityNumber', '==', patientIdentityNumber));

    try {
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
            const patientData = querySnapshot.docs[0].data();
            
            // Populate HTML with patient details
            document.getElementById('patientDetails').innerHTML = `
                <h3>Patient Details</h3>
                <p><strong>Name:</strong> ${patientData.fullName || ''}</p>
                <p><strong>Surname:</strong> ${patientData.surname || ''}</p>
                <p><strong>Date of Birth:</strong> ${patientData.dob || ''}</p>
                <p><strong>Contact Number:</strong> ${patientData.phone || ''}</p>
            `;
        } else {
            alert('No patient details found for this ID.');
        }
    } catch (error) {
        console.error('Error fetching patient details:', error);
        alert('Failed to load patient details.');
    }
}

// Image upload function with validation
async function uploadImage() {
    const fileInput = document.getElementById('imageUpload');
    const file = fileInput.files[0];
    const errorMessage = document.getElementById('errorMessage');
    const spinner = document.getElementById('loadingSpinner');

    errorMessage.textContent = ''; // Clear previous errors

    if (!file) {
        errorMessage.textContent = 'Please select an image to upload.';
        return;
    }

    const allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
    if (!allowedExtensions.exec(file.name)) {
        alert('Incorrect file type. Please upload JPEG, JPG, or PNG images.');
        fileInput.value = ''; // Reset the file input
        return false;
    }

    spinner.style.display = 'block';
    console.log('Uploading image...');

    const patientIdentityNumber = getPatientIdentityNumber(); // Get patient ID from URL
    try {
        const storageRef = ref(storage, `patients/${patientIdentityNumber}/images/${file.name}`);
        const snapshot = await uploadBytes(storageRef, file);
        const downloadURL = await getDownloadURL(snapshot.ref);

        const patientsRef = collection(firestore, 'Patients');
        const q = query(patientsRef, where('identityNumber', '==', patientIdentityNumber));
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
            const patientDoc = querySnapshot.docs[0];
            const patientRef = patientDoc.ref;

            await updateDoc(patientRef, { imageUrl: downloadURL });
            console.log('Image URL updated in Firestore.');

            window.location.href = 'imageUploaded.html'; // Redirect
        } else {
            errorMessage.textContent = 'Patient not found. Please try again.';
            console.warn('Patient document not found in Firestore.');
        }
    } catch (error) {
        errorMessage.textContent = 'Error uploading image. Please try again.';
        console.error('Error in upload process:', error);
    } finally {
        spinner.style.display = 'none';
    }
}

// Check authentication status and load patient details if signed in
onAuthStateChanged(auth, (user) => {
    if (user) {
        console.log("User is authenticated:", user);
        loadPatientDetails();
    } else {
        console.log("No authenticated user found, redirecting to sign-in page.");
        window.location.href = "signIn.html";
    }
});

// Prevent default form submission and trigger uploadImage function
document.getElementById("uploadForm").addEventListener("submit", function(event) {
    event.preventDefault();
    uploadImage();
});

// DOM Content Loaded
document.addEventListener("DOMContentLoaded", () => {
    loadPatientDetails();
});
