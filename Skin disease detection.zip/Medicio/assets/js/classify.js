document.addEventListener("DOMContentLoaded", function() {
    const classifyButton = document.querySelector("#classifyImageBtn");
  
    classifyButton.addEventListener("click", function(event) {
      event.preventDefault();
  
      // Create the modal content
      const modalContent = `
        <div class="modal fade" id="diagnosisModal" tabindex="-1" aria-labelledby="diagnosisModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="diagnosisModalLabel">Diagnosis</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <p><strong>Diagnosis:</strong> Melanocytic nevus</p>
                <p><strong>Description:</strong> Melanocytic nevus detected. If suspicious,
                 consider excisional biopsy with histopathological analysis.
                  Advise patient to monitor for hair changes, size, pigmentation, pain, itchiness, or burning of the mole,
                   red or irritated skin around the mole, blood or pus coming from the mole</p>
                  <p> Advise the patient to do follow ups regularly.</p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </div>
          </div>
        </div>
      `;
  
      // Append the modal to the body
      document.body.insertAdjacentHTML('beforeend', modalContent);
  
      // Initialize the Bootstrap modal and show it
      const diagnosisModal = new bootstrap.Modal(document.getElementById('diagnosisModal'));
      diagnosisModal.show();
  
      // Remove the modal from the DOM when hidden
      document.getElementById('diagnosisModal').addEventListener('hidden.bs.modal', function () {
        document.getElementById('diagnosisModal').remove();
      });
    });
  });
  