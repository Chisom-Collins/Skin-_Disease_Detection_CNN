import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

onAuthStateChanged(auth, (user) => {
    if (user) {
        document.getElementById("searchPatientForm").addEventListener("submit", async function (e) {
            e.preventDefault();
            const identityNumber = document.getElementById("identityNumber").value.trim();
            const errorMessage = document.getElementById("errorMessage");

            if (identityNumber === "") {
                errorMessage.textContent = "Please enter a valid Identity Number.";
                return;
            }

            try {
                const patientsRef = collection(db, "Patients");
                const q = query(patientsRef, where("identityNumber", "==", identityNumber));
                const querySnapshot = await getDocs(q);
                
                if (!querySnapshot.empty) {
                    const patientDoc = querySnapshot.docs[0];
                    const patientData = patientDoc.data();

                    const urlParams = new URLSearchParams({
                        patientId: patientData.identityNumber,
                        patientName: patientData.fullName,  
                        patientSurname: patientData.surname,
                        patientDOB: patientData.dob,  
                        patientContact: patientData.phone 
                    });

                    window.location.href = `capture.html?${urlParams.toString()}`;
                } else {
                    errorMessage.textContent = "Patient not found. Please re-enter the Identity Number.";
                }
            } catch (error) {
                errorMessage.textContent = "An error occurred. Please try again.";
            }
        });
    } else {
        window.location.href = "signIn.html";
    }
});
