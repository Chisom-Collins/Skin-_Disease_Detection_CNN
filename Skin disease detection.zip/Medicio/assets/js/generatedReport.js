import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, query, where, getDocs } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";
import { getStorage, ref, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js";

const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);

let dermatologistName = "Unknown";

onAuthStateChanged(auth, (user) => {
    if (!user) {
        window.location.href = "signIn.html";
    } else {
        dermatologistName = user.displayName || user.email || "Dermatologist";
    }
});

async function displayPatientDetails() {
    const patientId = sessionStorage.getItem('patientId');
    if (patientId) {
        const patientsRef = collection(db, "Patients");
        const q = query(patientsRef, where("identityNumber", "==", patientId.trim()));
        const querySnapshot = await getDocs(q);

        if (!querySnapshot.empty) {
            const docSnap = querySnapshot.docs[0];
            const data = docSnap.data();

            document.getElementById('patientName').innerText = data.fullName || "N/A";
            document.getElementById('patientSurname').innerText = data.surname || "N/A";
            document.getElementById('patientID').innerText = data.identityNumber || "N/A";
            document.getElementById('cellPhoneNumber').innerText = data.phone || "N/A";
            document.getElementById('medicalAidNumber').innerText = data.medicalAidNumber || "N/A";
            document.getElementById('dob').innerText = data.dob || "N/A";
            document.getElementById('diagnosis').innerText = data.diagnosis || "N/A";
            document.getElementById('dateConsulted').innerText = new Date().toLocaleString();

            if (data.imageUrl) {
                try {
                    const imageRef = ref(storage, data.imageUrl);
                    const imageUrl = await getDownloadURL(imageRef);
                    document.getElementById('patientImage').src = imageUrl;
                    document.getElementById('patientImageContainer').style.display = "block";
                    sessionStorage.setItem('patientImageUrl', imageUrl);
                } catch (error) {
                    console.error("Error fetching image:", error);
                }
            }
        } else {
            alert("Patient not found in the database.");
        }
    } else {
        alert("No Patient ID found in session storage.");
    }
}

function exportReportAsPDF() {
    const { jsPDF } = window.jspdf;
    
    const doc = new jsPDF();

    // Add Border
    doc.setLineWidth(0.5);
    doc.rect(5, 5, 200, 287); // Border around the entire document

    // Title Styling
    doc.setFont("helvetica", "bold");
    doc.setFontSize(20);
    doc.setTextColor(0, 51, 102);
    doc.text("Patient Report", 105, 20, null, null, "center");

    // Patient Information with Improved Styling
    doc.setFontSize(12);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(60, 60, 60);

    // Patient Details
    const patientDetailsY = 40;
    doc.setFont("helvetica", "bold");
    doc.text("Patient Information:", 10, patientDetailsY);
    doc.setFont("helvetica", "normal");
    doc.text(`Name: ${document.getElementById('patientName').innerText}`, 10, patientDetailsY + 10);
    doc.text(`Surname: ${document.getElementById('patientSurname').innerText}`, 10, patientDetailsY + 20);
    doc.text(`ID: ${document.getElementById('patientID').innerText}`, 10, patientDetailsY + 30);
    doc.text(`Phone: ${document.getElementById('cellPhoneNumber').innerText}`, 10, patientDetailsY + 40);
    doc.text(`Medical Aid: ${document.getElementById('medicalAidNumber').innerText}`, 10, patientDetailsY + 50);
    doc.text(`DOB: ${document.getElementById('dob').innerText}`, 10, patientDetailsY + 60);

    // Diagnosis
    const diagnosisY = patientDetailsY + 80;
    doc.setFont("helvetica", "bold");
    doc.text("Diagnosis:", 10, diagnosisY);
    doc.setFont("helvetica", "normal");
    doc.text(`${document.getElementById('diagnosis').innerText}`, 10, diagnosisY + 10);

    // Add Description
    const descriptionY = diagnosisY + 30;
    const descriptionText = `
Melanocytic nevus detected. If suspicious, consider excisional biopsy with histopathological analysis.
Advise patient to monitor for any changes in the mole's hair growth, size, pigmentation, sensation, or appearance.
Regular follow-ups are recommended.
    `;
    doc.setFont("helvetica", "bold");
    doc.text("Description:", 10, descriptionY);
    doc.setFont("helvetica", "normal");
    doc.text(descriptionText, 10, descriptionY + 10, { maxWidth: 180 });

    // Date Consulted
    const dateConsultedY = descriptionY + 40;
    doc.setFont("helvetica", "bold");
    doc.text("Date Consulted:", 10, dateConsultedY);
    doc.setFont("helvetica", "normal");
    doc.text(`${document.getElementById('dateConsulted').innerText}`, 50, dateConsultedY);

    // Load Patient Image
    const imageUrl = sessionStorage.getItem('patientImageUrl');
    if (imageUrl) {
        fetch(imageUrl)
            .then(response => response.blob())
            .then(blob => {
                const reader = new FileReader();
                reader.onload = function () {
                    const base64Image = reader.result;

                    // Adding the image to the PDF once it is ready
                    doc.addImage(base64Image, 'JPEG', 140, 40, 50, 50); // Placing image at top-right
                    addFooter(doc);
                    doc.save("Patient_Report.pdf");
                };
                reader.onerror = function () {
                    console.error("Error reading image blob.");
                    addFooter(doc);
                    doc.save("Patient_Report.pdf");
                };
                reader.readAsDataURL(blob);
            })
            .catch(error => {
                console.error("Error loading image:", error);
                addFooter(doc);
                doc.save("Patient_Report.pdf");
            });
    } else {
        console.warn("No image URL found in session storage.");
        addFooter(doc);
        doc.save("Patient_Report.pdf");
    }
}

// Add footer with generation info
function addFooter(doc) {
    const currentDate = new Date();
    const dateTime = currentDate.toLocaleString();
    doc.setFontSize(10);
    doc.setTextColor(100);

    doc.text("Generated by: " + dermatologistName, 10, 280);
    doc.text(`Date and Time Generated: ${dateTime}`, 105, 280, null, null, "center");
    doc.text("© PixelDerm", 200, 280, null, null, "right");
}

document.addEventListener("DOMContentLoaded", () => {
    displayPatientDetails();

    const exportPDFBtn = document.getElementById("exportPDFBtn");
    if (exportPDFBtn) {
        exportPDFBtn.addEventListener("click", exportReportAsPDF);
    }
});
