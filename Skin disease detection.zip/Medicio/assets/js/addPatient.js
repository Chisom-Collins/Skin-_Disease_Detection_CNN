import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, addDoc, getDoc, doc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
  authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
  projectId: "pixelderm-admin-dashboard",
  storageBucket: "pixelderm-admin-dashboard.appspot.com",
  messagingSenderId: "625373796019",
  appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Add patient data to Firestore
document.getElementById('newPatientForm').addEventListener('submit', async function(event) {
  event.preventDefault(); 

  const patientName = document.getElementById('patientName').value;
  const patientSurname = document.getElementById('patientSurname').value;
  const patientIdentityNumber = document.getElementById('patientIdentityNumber').value;
  const patientDOB = document.getElementById('patientDOB').value;
  const patientPhone = document.getElementById('patientPhone').value;
  const medicalAidNumber = document.getElementById('medicalAidNumber').value;
  const message = document.getElementById('message'); 

  // Validate that all fields are filled
  if (patientName && patientSurname && patientIdentityNumber && patientDOB && patientPhone && medicalAidNumber) {
    const confirmation = confirm("Are you sure you want to add this patient?");
    
    if (confirmation) {
      try {
        // Check if user is authenticated and get dermatologist data
        onAuthStateChanged(auth, async (user) => {
          if (user) {
            const dermatologistRef = doc(db, "Dermatologists", user.uid);
            const dermatologistSnap = await getDoc(dermatologistRef);

            if (dermatologistSnap.exists()) {
              const dermatologistData = dermatologistSnap.data();
              const dermatologistName = dermatologistData.fullName; // Assuming 'fullName' field exists

              // Add patient data to Firestore
              const docRef = await addDoc(collection(db, 'Patients'), {
                fullName: patientName,
                surname: patientSurname,
                identityNumber: patientIdentityNumber,
                dob: patientDOB,
                phone: patientPhone,
                medicalAidNumber: medicalAidNumber,
                createdAt: serverTimestamp(),
                addedBy: { 
                  dermatologistUID: user.uid, 
                  dermatologistName: dermatologistName 
                }
              });

              // Save patientId to localStorage for later use in image upload
              const patientId = docRef.id;
              localStorage.setItem('patientId', patientId);

              alert("Patient Added Successfully");
              // Redirect to the image upload page
              window.location.href = "actualpage.html";
            } else {
              console.error("No dermatologist data found for this user.");
            }
          } else {
            alert("You must be logged in to add a patient.");
            window.location.href = "login.html";
          }
        });
      } catch (error) {
        console.error("Error adding patient:", error);
        message.style.color = 'red';
        message.textContent = 'Error adding patient. Please try again.';
      }
    } else {
      message.style.color = 'blue';
      message.textContent = 'You canceled the operation.';
    }
  } else {
    // Display message if any field is missing
    message.style.color = 'red';
    message.textContent = 'Please fill in all fields';
  }
});
