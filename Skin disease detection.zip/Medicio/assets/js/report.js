import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, getDocs, query, where } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

function handleSignOut() {
    signOut(auth)
        .then(() => {
            window.location.href = 'signin.html';
        })
        .catch((error) => {
            console.error('Sign out error: ', error);
            alert('An error occurred while signing out. Please try again.');
        });
}

function searchPatientById(patientId) {
    const patientRef = collection(db, 'Patients');
    const q = query(patientRef, where('identityNumber', '==', patientId));

    getDocs(q)
        .then((querySnapshot) => {
            if (querySnapshot.empty) {
                document.getElementById('errorMessage').style.display = 'block';
                document.getElementById('patientInfo').style.display = 'none';
            } else {
                querySnapshot.forEach((doc) => {
                    const patientData = doc.data();
                    sessionStorage.setItem('patientName', patientData.fullName);
                    sessionStorage.setItem('patientSurname', patientData.surname);
                    sessionStorage.setItem('patientId', patientData.identityNumber);

                    // Optionally display patient info before redirecting
                   
                    document.getElementById('errorMessage').style.display = 'none';
                    
                    // Redirect to generatedReport.html
                    window.location.href = 'generatedReport.html';
                });
            }
        })
        .catch((error) => {
            console.error('Error searching for patient: ', error);
            alert('An error occurred while searching. Please try again.');
        });
}

onAuthStateChanged(auth, (user) => {
    if (user) {
        document.getElementById('searchForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const patientId = document.getElementById('identityNumber').value.trim();
            if (!patientId) {
                alert('Please enter a Patient Identity Number.');
                return;
            }
            document.getElementById('errorMessage').style.display = 'none';
            searchPatientById(patientId);
        });

        document.getElementById('signinBtn').addEventListener('click', handleSignOut);
    } else {
        window.location.href = 'signIn.html';
    }
});
