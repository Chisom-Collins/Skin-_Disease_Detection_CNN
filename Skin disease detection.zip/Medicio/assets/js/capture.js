import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, query, where, getDocs, doc, setDoc } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { getStorage } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-storage.js';
import { getAuth, onAuthStateChanged } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js';
import { setPersistence, browserSessionPersistence } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js';

const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase services
const app = initializeApp(firebaseConfig);
const firestore = getFirestore(app);
const storage = getStorage(app);
const auth = getAuth(app);

// Set authentication persistence
setPersistence(auth, browserSessionPersistence)
    .then(() => console.log("Auth persistence set to session"))
    .catch(error => console.error("Error setting auth persistence:", error));

// Get the patient identity number from the URL
function getPatientIdentityNumber() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('patientId'); 
}

// Load patient details from Firestore
async function loadPatientDetails() {
    const patientIdentityNumber = getPatientIdentityNumber();
    if (!patientIdentityNumber) {
        alert('Patient ID not found. Please check the URL.');
        return;
    }

    const patientsRef = collection(firestore, 'Patients');
    const q = query(patientsRef, where('identityNumber', '==', patientIdentityNumber));

    try {
        const querySnapshot = await getDocs(q);
        if (!querySnapshot.empty) {
            const patientData = querySnapshot.docs[0].data();
            document.getElementById('patientDetails').innerHTML = `
                <h3>Patient Details</h3>
                <p><strong>Name:</strong> ${patientData.fullName || ''}</p>
                <p><strong>Surname:</strong> ${patientData.surname || ''}</p>
                <p><strong>Date of Birth:</strong> ${patientData.dob || ''}</p>
                <p><strong>Contact Number:</strong> ${patientData.phone || ''}</p>
            `;
        } else {
            alert('No patient details found for this ID.');
        }
    } catch (error) {
        console.error('Error fetching patient details:', error);
        alert('Failed to load patient details.');
    }
}

// Set up the "Open Camera" button event
function setupCaptureButton() {
    const captureButton = document.getElementById('captureButton');
    if (captureButton) {
        captureButton.addEventListener('click', openCamera);
        console.log("Capture button event listener set.");
    } else {
        console.error("Capture button not found in the DOM.");
    }
}

// Set up "Snap" button for capturing image
function setupSnapButton() {
    const snapButton = document.getElementById('snapButton');
    if (snapButton) {
        snapButton.addEventListener('click', captureImage);
    } else {
        console.error("Snap button not found in the DOM.");
    }
}

// Open the camera function
function openCamera() {
    const video = document.getElementById('camera');
    const snapButton = document.getElementById('snapButton');
    const captureButton = document.getElementById('captureButton');
    const retakeButton = document.getElementById('retakeButton');
    const capturedImage = document.getElementById('capturedImage');
    
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function(stream) {
                video.srcObject = stream;
                video.style.display = 'block';
                snapButton.style.display = 'inline';
                captureButton.style.display = 'none';
                retakeButton.style.display = 'none';
                capturedImage.style.display = 'none';
            })
            .catch(function(error) {
                console.error("Error accessing the camera: ", error);
                alert("Failed to access the camera. Please check browser permissions or connection.");
            });
    } else {
        alert("Your browser does not support accessing the camera.");
    }
}

// Capture and store an image
async function captureImage() {
    const video = document.getElementById('camera');
    const canvas = document.getElementById('canvas');
    const snapButton = document.getElementById('snapButton');
    const retakeButton = document.getElementById('retakeButton');
    const captureButton = document.getElementById('captureButton');
    const capturedImage = document.getElementById('capturedImage');
    const patientId = getPatientIdentityNumber();

    if (video.videoWidth > 0 && video.videoHeight > 0) {
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);

        const dataUrl = canvas.toDataURL('image/png');

        video.srcObject.getTracks().forEach(track => track.stop());
        video.style.display = 'none';
        snapButton.style.display = 'none';
        captureButton.style.display = 'inline';
        retakeButton.style.display = 'inline';
        capturedImage.src = dataUrl;
        capturedImage.style.display = 'block';

        // Store image URL in Firestore
        if (patientId) {
            const patientRef = doc(firestore, "Patients", patientId);
            try {
                await setDoc(patientRef, { imageUrl: dataUrl }, { merge: true });
                alert('Image URL stored in Firestore successfully!');
            } catch (error) {
                console.error("Error storing image URL: ", error);
                alert('Failed to store the image URL. Check the console for errors.');
            }
        } else {
            alert("Patient ID is not defined.");
        }
    } else {
        alert('Video stream is not available. Please ensure the camera is active.');
    }
}

// Retake Image
function retakeImage() {
    const video = document.getElementById('camera');
    const snapButton = document.getElementById('snapButton');
    const captureButton = document.getElementById('captureButton');
    const retakeButton = document.getElementById('retakeButton');
    const capturedImage = document.getElementById('capturedImage');

    video.style.display = 'block';
    snapButton.style.display = 'inline';
    captureButton.style.display = 'none';
    retakeButton.style.display = 'none';
    capturedImage.style.display = 'none';

    navigator.mediaDevices.getUserMedia({ video: true })
        .then(function(stream) {
            video.srcObject = stream;
        })
        .catch(function(error) {
            console.error("Error accessing the camera: ", error);
            alert("Failed to access the camera. Please check browser permissions or connection.");
        });
}

// Authentication handler
onAuthStateChanged(auth, (user) => {
    if (user) {
        loadPatientDetails();
    } else {
        console.log("No authenticated user found, redirecting to sign-in page.");
        window.location.href = "signIn.html";
    }
});

// Prevent default form submission and trigger captureImage function
document.getElementById("uploadForm")?.addEventListener("submit", function(event) {
    event.preventDefault();
    captureImage();
});

// DOM Content Loaded
document.addEventListener("DOMContentLoaded", () => {
    loadPatientDetails();
    setupCaptureButton(); // Set up the event listener after the DOM is loaded
    setupSnapButton();    // Set up Snap button listener
});
