// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, doc, setDoc } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth, createUserWithEmailAndPassword, sendEmailVerification, signOut } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth();

// Function to validate email
function validateEmail(email) {
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
}
// Function to toggle visibility of the 'Other Hospital' input
function toggleHospitalInput() {
    const hospitalSelect = document.getElementById('selectHospital');
    const otherHospitalInput = document.getElementById('otherHospital');
    
    if (hospitalSelect.value === 'Other') {
        otherHospitalInput.style.display = 'block'; 
    } else {
        otherHospitalInput.style.display = 'none';
    }
}

// Validate form and create dermatologist account
function validateForm(event) {
    event.preventDefault();
    const fullName = document.getElementById('full-name').value.trim();
    const email = document.getElementById('email').value.trim();
    const drIdNo = document.getElementById('drIdNo').value.trim();
    const hospital = document.getElementById('selectHospital').value;
    const otherHospital = document.getElementById('otherHospital').value.trim();
    const password = document.getElementById('signupPassword').value.trim();

    let errorMessage = "";
    if (!fullName) errorMessage += "Full name is required.\n";
    if (!email || !validateEmail(email)) errorMessage += "Valid email is required.\n";
    if (!drIdNo) errorMessage += "Doctor identity number is required.\n";
    if (!hospital) errorMessage += "Please select a hospital.\n";
    if (hospital === 'Other' && !otherHospital) errorMessage += "Please specify the hospital.\n";
    if (!password) errorMessage += "Password is required.\n";

    if (errorMessage) {
        alert(errorMessage);
    } else {
        // Confirm details with the user
        const confirmation = confirm(`Please confirm the details you entered:\n\nFull Name: ${fullName}\nEmail: ${email}\nDoctor ID: ${drIdNo}\nHospital: 
            ${hospital === 'Other' ? otherHospital : hospital}\n\nAre these details correct?`);

        if (confirmation) {
            const admin = auth.currentUser;

            if (!admin) {
                alert("Admin is not logged in.");
                return;
            }

            const adminId = admin.uid;

            createUserWithEmailAndPassword(auth, email, password)
                .then((userCredential) => {
                    const user = userCredential.user;
                    const dermatologistId = user.uid;

                    // Save dermatologist data under the admin's ID and also in the global Dermatologists collection
                    return setDoc(doc(db, 'Admins', adminId, 'Dermatologists', dermatologistId), {
                        fullName: fullName,
                        email: email,
                        doctorIdentityNumber: drIdNo,
                        hospital: hospital === 'Other' ? otherHospital : hospital,
                        status: 'Inactive'
                    }).then(() => {
                        return setDoc(doc(db, 'Dermatologists', dermatologistId), {
                            fullName: fullName,
                            email: email,
                            doctorIdentityNumber: drIdNo,
                            hospital: hospital === 'Other' ? otherHospital : hospital,
                            status: 'Inactive',
                            adminId: adminId // this references to the admin who created this dermatologist
                        });
                    });
                })
                .then(() => {
                    sendEmailVerification(auth.currentUser)
                        .then(() => {
                            alert('Dermatologist account created! Verification email sent.');
                        });
                })
                .catch((error) => {
                    alert('Error: ' + error.message);
                });
        } else {
            // User selected "No" - stay on the form with data intact
            alert("Please review the details and make changes if needed.");
        }
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('dermatologistForm');
    if (form) {
        form.addEventListener('submit', validateForm);
    }

    const hospitalSelect = document.getElementById('selectHospital');
    if (hospitalSelect) {
        hospitalSelect.addEventListener('change', toggleHospitalInput);
    }

    const signOutButton = document.querySelector('.signOut-Btn');
    if (signOutButton) {
        signOutButton.addEventListener('click', () => {
            signOut(auth).then(() => {
                alert('Signed out successfully.');
                window.location.href = 'signin.html';
            }).catch((error) => {
                alert('Sign out failed: ' + error.message);
            });
        });
    }
});
