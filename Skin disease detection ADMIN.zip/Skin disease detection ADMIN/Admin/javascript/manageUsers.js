// Import and configure Firebase
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js';
import { getFirestore, collection, getDocs, doc, getDoc, deleteDoc, updateDoc } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js';
import { getAuth, signOut } from 'https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js';

const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Load users into the table
async function loadUsers() {
    const userTableBody = document.getElementById('userTable').getElementsByTagName('tbody')[0];
    userTableBody.innerHTML = ''; // Clear table

    try {
        const querySnapshot = await getDocs(collection(db, 'Dermatologists'));
        querySnapshot.forEach((doc) => {
            const user = doc.data();
            const userId = doc.id;

            // Create a new row for each user
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${user.doctorIdentityNumber}</td>
                <td>${user.fullName}</td>
                <td>${user.hospital}</td>
                <td>
                    <button class="action-button update-button" data-user-id="${userId}">Update</button>
                    <button class="action-button delete-button" data-user-id="${userId}">Delete</button>
                </td>
            `;
            userTableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading dermatologists:', error);
    }
}

// Delete a user with confirmation
async function deleteUser(userId) {
    const confirmation = confirm("Are you sure you want to delete this user?");
    if (confirmation) {
        try {
            await deleteDoc(doc(db, 'Dermatologists', userId));
            alert("User deleted successfully.");
            loadUsers();
        } catch (error) {
            console.error("Error deleting user:", error);
        }
    }
}

// Update a user by showing a form with existing data
async function updateUser(userId) {
    // Get the user's current information
    const userRef = doc(db, 'Dermatologists', userId);
    const userDoc = await getDoc(userRef);

    if (userDoc.exists()) {
        const user = userDoc.data();
        // Display the update form with user data pre-filled
        document.getElementById('updateFormContainer').style.display = 'block';
        document.getElementById('fullName').value = user.fullName || '';
        document.getElementById('email').value = user.email || '';
        document.getElementById('hospital').value = user.hospital || '';

        // Handle form submission
        const updateForm = document.getElementById('updateForm');
        updateForm.onsubmit = async function (event) {
            event.preventDefault();

            // Show confirmation dialog before updating
            const confirmation = confirm("Are you sure you want to update this information?");
            if (confirmation) {
                // Get updated values from the form fields
                const updatedFullName = document.getElementById('fullName').value;
                const updatedEmail = document.getElementById('email').value;
                const updatedHospital = document.getElementById('hospital').value;

                // Update user information in Firebase
                try {
                    await updateDoc(userRef, {
                        fullName: updatedFullName,
                        email: updatedEmail,
                        hospital: updatedHospital
                    });
                    alert('User information updated successfully.');
                    loadUsers(); // Reload the user list
                    document.getElementById('updateFormContainer').style.display = 'none';
                } catch (error) {
                    console.error('Error updating user:', error);
                    alert('Failed to update user information.');
                }
            } else {
                // Close the form and return to the manageUsers.html page
                document.getElementById('updateFormContainer').style.display = 'none';
                window.location.href = 'manage.html';
            }
        };
    } else {
        alert('User not found.');
    }
}

// Event listener for button actions
document.addEventListener('click', async (event) => {
    const target = event.target;
    const userId = target.getAttribute('data-user-id');

    if (target.classList.contains('update-button')) {
        await updateUser(userId);
    } else if (target.classList.contains('delete-button')) {
        await deleteUser(userId);
    }
});

// Close the update form when the "Cancel" button is clicked
document.getElementById('cancelUpdate').addEventListener('click', () => {
    document.getElementById('updateFormContainer').style.display = 'none';
});

// Sign out functionality
document.querySelector('.signOut-Btn').addEventListener('click', async () => {
    try {
        await signOut(auth);
        window.location.href = 'signin.html';
    } catch (error) {
        console.error('Error signing out:', error);
    }
});

// Load users on page load
window.addEventListener('load', () => {
    auth.onAuthStateChanged((user) => {
        if (user) {
            loadUsers();
        } else {
            window.location.href = 'signin.html';
        }
    });
});
