document.addEventListener('DOMContentLoaded', function () {
    const signOutBtn = document.querySelector('.signOut-Btn');
    signOutBtn.addEventListener('click', function () {
        alert('You have successfully signed out.');
        window.location.href = 'signin.html'; // Redirect to the sign-in page
    });
});
