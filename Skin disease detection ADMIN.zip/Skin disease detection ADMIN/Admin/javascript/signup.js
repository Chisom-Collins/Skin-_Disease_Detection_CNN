import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getDatabase, set, ref } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-database.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
  authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
  databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
  projectId: "pixelderm-admin-dashboard",
  storageBucket: "pixelderm-admin-dashboard.appspot.com",
  messagingSenderId: "625373796019",
  appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const auth = getAuth();

document.addEventListener('DOMContentLoaded', function () {
  const registerForm = document.querySelector('form');
  const fullNameInput = document.getElementById('full-name');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const retypePasswordInput = document.getElementById('retype-password');

  registerForm.addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent default form submission

    const fullName = fullNameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value.trim();
    const retypePassword = retypePasswordInput.value.trim();

    // Validate full name
    if (fullName === '') {
      alert('Please enter your full name.');
      return;
    }

    // Validate email
    if (!validateEmail(email)) {
      alert('Please enter a valid email address.');
      return;
    }

    // Validate password and retyped password
    if (password === '') {
      alert('Please create a password.');
      return;
    }

    if (password !== retypePassword) {
      alert('Passwords do not match. Please retype the password.');
      return;
    }

    // Firebase create user with email and password
    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        // Registration successful, store additional user info in the database
        set(ref(database, 'users/' + userCredential.user.uid), {
          fullName: fullName,
          email: email
        })
        .then(() => {
          alert('Registration successful!');
          window.location.href = 'signin.html';
        })
        .catch((error) => {
          alert('Failed to save user data: ' + error.message);
        });
      })
      .catch((error) => {
        alert(error.message);
      });
  });

  // Function to validate email
  function validateEmail(email) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
  }
});
