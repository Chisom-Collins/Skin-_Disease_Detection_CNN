// Import Firebase Admin SDK
const admin = require("firebase-admin");
const express = require("express"); // Express server to handle API calls
const app = express();

// Initialize Firebase Admin SDK with service account credentials
const serviceAccount = require("/path/to/serviceAccountKey.json"); // Replace with the actual path

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com"
});

// Middleware to check if the user has an admin claim
async function checkAdmin(req, res, next) {
    const idToken = req.headers.authorization;
    try {
        const decodedToken = await admin.auth().verifyIdToken(idToken);
        if (decodedToken.admin) {
            req.user = decodedToken;
            next();
        } else {
            res.status(403).send("Access denied: Admin privileges required.");
        }
    } catch (error) {
        res.status(401).send("Unauthorized: Invalid token.");
    }
}

// Endpoint to get dermatologist and patient counts
app.get("/getCounts", checkAdmin, async (req, res) => {
    try {
        const dermatologistSnapshot = await admin.firestore().collection("Dermatologists").get();
        const patientSnapshot = await admin.firestore().collection("Patients").get();
        const totalDermatologists = dermatologistSnapshot.size;
        const totalPatients = patientSnapshot.size;

        res.json({
            totalDermatologists,
            totalPatients
        });
    } catch (error) {
        console.error("Error fetching counts:", error);
        res.status(500).send("Error fetching counts.");
    }
});

// Start the server
app.listen(5000, () => {
    console.log("Admin API running on port 5000");
});
