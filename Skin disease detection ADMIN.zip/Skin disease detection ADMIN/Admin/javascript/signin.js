import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getDatabase, ref, update } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-database.js";
import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Your Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);
const auth = getAuth();

document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.querySelector('form');
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    const loader = document.getElementById('loader');

    // Add submit event listener to the login form
    loginForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent default form submission

        const email = emailInput.value.trim();
        const password = passwordInput.value.trim();

        // Simple email and password validation
        if (!validateEmail(email)) {
            alert('Please enter a valid email address.');
            return;
        }

        if (password === '') {
            alert('Please enter your password.');
            return;
        }

        // Show loader while the authentication process is happening
        loader.style.display = 'block';

        // Firebase Authentication: Sign in with email and password
        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                // Signed in successfully
                const user = userCredential.user;

                // Save user data in the database
                const dt = new Date();
                return update(ref(database, 'users/' + user.uid), {
                    email: email,
                    last_login: dt,
                });
            })
            .then(() => {
                // After user data is successfully updated
                loader.style.display = 'none'; // Hide loader
                alert('User logged in!');
                window.location.href = 'admin.html'; // Redirect to admin page
            })
            .catch((error) => {
                loader.style.display = 'none'; // Hide loader on error
                alert('Error: ' + error.message);
            });
    });

    // Function to validate email format
    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }
});
