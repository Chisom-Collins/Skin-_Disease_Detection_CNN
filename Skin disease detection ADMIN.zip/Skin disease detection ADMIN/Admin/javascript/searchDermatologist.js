// Import Firebase dependencies
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, getDocs, query, where } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth, signOut, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Firebase configuration (replace with your Firebase config)
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    databaseURL: "https://pixelderm-admin-dashboard-default-rtdb.firebaseio.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Function to handle sign-out
function handleSignOut() {
    signOut(auth)
        .then(() => {
            // Sign-out successful, redirect to the sign-in page
            window.location.href = 'signin.html';
        })
        .catch((error) => {
            console.error('Sign out error: ', error);
            alert('An error occurred while signing out. Please try again.');
        });
}

// Function to handle search for dermatologist by ID
function searchDermatologistById(dermatologistId) {
    const dermatologistsRef = collection(db, 'Dermatologists');
    const q = query(dermatologistsRef, where('doctorIdentityNumber', '==', dermatologistId));

    getDocs(q)
        .then((querySnapshot) => {
            if (querySnapshot.empty) {
                alert('Dermatologist not found. Please re-enter the Dermatologist ID.');
            } else {
                window.location.href = 'foundDerm.html';
            }
        })
        .catch((error) => {
            console.error('Error searching dermatologist: ', error);
            alert('An error occurred while searching. Please try again.');
        });
}

// Check if admin is authenticated
onAuthStateChanged(auth, (user) => {
    if (user) {
        // User is authenticated, allow search functionality
        document.getElementById('searchForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const dermatologistId = document.getElementById('dermatologistId').value;
            if (!dermatologistId) {
                alert('Please enter a Dermatologist Identity Number.');
                return;
            }
            // Call search function
            searchDermatologistById(dermatologistId);
        });

        // Add sign-out button functionality
        document.getElementById('signOutBtn').addEventListener('click', handleSignOut);

    } else {
        window.location.href = 'signin.html';
    }
});
