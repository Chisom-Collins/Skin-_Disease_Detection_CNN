import { initializeApp } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-firestore.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.13.2/firebase-auth.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBKQLLYF5NS9qO2xR4x7LXl2lrP7eC6lew",
    authDomain: "pixelderm-admin-dashboard.firebaseapp.com",
    projectId: "pixelderm-admin-dashboard",
    storageBucket: "pixelderm-admin-dashboard.appspot.com",
    messagingSenderId: "625373796019",
    appId: "1:625373796019:web:64cbcc07da5e4385f6c2c6"
};

// Initialize Firebase and Firestore
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth();

// Function to get frequency of each diagnosis over time (by month or week)
async function getDiagnosisFrequencyOverTime() {
    const diagnosisFrequency = {};
    const dateGroupedFrequency = {};

    try {
        const querySnapshot = await getDocs(collection(db, "Diagnoses"));
        querySnapshot.forEach((doc) => {
            const data = doc.data();
            const diagnosisType = data.diagnosisType; // Assuming 'diagnosisType' field is in the data
            const diagnosisDate = new Date(data.diagnosisDate); // Assuming 'diagnosisDate' is a timestamp

            // Group diagnoses by month (you can change this to week if preferred)
            const month = diagnosisDate.toLocaleString('default', { month: 'long', year: 'numeric' }); // e.g., 'January 2024'

            // Initialize the count for that diagnosis type in that month
            if (!dateGroupedFrequency[month]) {
                dateGroupedFrequency[month] = {};
            }
            dateGroupedFrequency[month][diagnosisType] = (dateGroupedFrequency[month][diagnosisType] || 0) + 1;
        });

        console.log("Diagnosis Frequency Over Time:", dateGroupedFrequency); // Debug: Log the frequency of each diagnosis by time period
        renderDiagnosisFrequencyOverTimeChart(dateGroupedFrequency);
    } catch (error) {
        console.error("Error retrieving diagnosis frequency over time:", error);
    }
}

// Function to render the frequency of each diagnosis over time chart
function renderDiagnosisFrequencyOverTimeChart(dateGroupedFrequency) {
    const ctx = document.getElementById("diagnosisFrequencyOverTimeChart").getContext("2d");

    // Convert the data into arrays for charting
    const months = Object.keys(dateGroupedFrequency);
    const diagnosesByMonth = months.map(month => {
        const diagnosesCount = Object.values(dateGroupedFrequency[month]);
        return diagnosesCount.reduce((a, b) => a + b, 0); // Sum all diagnoses in that month
    });

    // Generate the chart data
    new Chart(ctx, {
        type: "line", // Line chart to track changes over time
        data: {
            labels: months, // X-axis: months or weeks
            datasets: [{
                label: "Total Diagnoses per Month",
                data: diagnosesByMonth, // Y-axis: total number of diagnoses
                backgroundColor: "rgba(75, 192, 192, 0.2)",
                borderColor: "rgba(75, 192, 192, 1)",
                borderWidth: 2,
                fill: false, // No fill for the line chart
                tension: 0.1 // Smooth the line curve
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    labels: {
                        color: "#333",
                        font: {
                            size: 14
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: "#333",
                        font: {
                            size: 12
                        }
                    }
                },
                y:{
                    title: {
                       display: true,
                       text: "Number of Patients"
                   },
                   beginAtZero: true,
                   min: 0,
                   max: 6,
                   ticks: {
                       stepSize: 1, // Ensures y-axis displays whole numbers
                       callback: function(value)
                        { return Number.isInteger(value) ? value : null; }
                   }
                   }
            }
        }
    });
}

// Call the functions to fetch data and render the charts
getDiagnosisFrequencyOverTime();
